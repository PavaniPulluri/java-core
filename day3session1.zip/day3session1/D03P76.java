package com.learning.core.day3session1;

import java.util.TreeSet;


public class D03P76 {
    public static void main(String[] args) {
        // Pre-defined information of 6 persons
        Person person1 = new Person(1, "Jerry", 30, 999.0);
        Person person2 = new Person(2, "Smith", 28, 2999.0);
        Person person3 = new Person(3, "Popeye", 25, 5999.0);
        Person person4 = new Person(4, "Jones", 35, 6999.0);
        Person person5 = new Person(5, "John", 20, 1999.0);
        Person person6 = new Person(6, "Tom", 40, 3999.0);

        // Store persons in a TreeSet (sorted based on ID)
        TreeSet<Person> personSet = new TreeSet<>();
        personSet.add(person1);
        personSet.add(person2);
        personSet.add(person3);
        personSet.add(person4);
        personSet.add(person5);
        personSet.add(person6);

        // Print ID, name, and salary of each person
        for (Person person : personSet) {
            System.out.println( + person.getId() + ", " + person.getName() + "," + person.getSalary());
        }
    }
}