package com.learning.core.day3session1;

import java.util.ArrayList;
import java.util.Scanner;

public class D03P71 {
    public static void main(String[] args) {
        // Creating an ArrayList to store student names
        ArrayList<String> studentNames = new ArrayList<>();

        // Adding student names to the ArrayList (You can customize this part)
        studentNames.add("Jack");
        studentNames.add("Paul");
        studentNames.add("Henry");
        studentNames.add("Mary");
        studentNames.add("Ronaldo");

        // Taking manual input for the name to search
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name to search: ");
        String nameToSearch = scanner.nextLine();

        // Checking if the name exists in the list
        if (studentNames.contains(nameToSearch)) {
            System.out.println(nameToSearch + " exists in the list.");
        } else {
            System.out.println(nameToSearch + " does not exist in the list.");
        }
    }
}